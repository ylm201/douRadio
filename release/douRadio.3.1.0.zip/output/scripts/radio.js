seajs.config({
  base: "/static/",
});
seajs.use("background/1.0.0/background");
