seajs.config({
  base: "/static/",
});
seajs.use("popup/1.0.0/main");
